Original double-read while halted. No FLASH or UICR mutation. Producer-reported OpenOCD provenance; no hardware qualification.
